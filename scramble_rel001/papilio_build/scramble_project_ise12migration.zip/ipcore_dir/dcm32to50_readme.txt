The following files were generated for 'dcm32to50' in directory 
C:\Documents and Settings\JZarsuel\My Documents\Dropbox\ondesk\scramble_rel001\papilio_build\ipcore_dir\

dcm32to50_readme.txt:
   Text file indicating the files generated and how they are used.

dcm32to50_xmdf.tcl:
   ISE Project Navigator interface file. ISE uses this file to determine
   how the files output by CORE Generator for the core can be integrated
   into your ISE project.

dcm32to50_flist.txt:
   Text file listing all of the output files produced when a customized
   core was generated in the CORE Generator.


Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

