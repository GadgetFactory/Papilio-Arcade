Note, these are not the original rom images.

These are for a pong demo game by David Widel, see
http://www.widel.com/

You can of course replace them with whatever you want.

/MikeJ
